package com.org.club.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.club.Entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer> {

}
